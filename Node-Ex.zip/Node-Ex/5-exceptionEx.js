divison = (num1, num2) => {   
    try {      
        if(isNaN(num1) || isNaN(num2)) 
            throw new Error('Provided values contains alphabets..');
        if (num2 === 0)         
            throw new Error('Division not possible with 0') 
        result = num1/num2;
        console.log(result)
    }
    catch (err) { 
            console.log('Error ! ' + err.message);
            console.log('Thank u for using....');
    }
}

divison(50, 2);
divison(50, 0);
divison(50, 'm');
divison(10,5);