var fn = function printFunction(num, msg) {
    console.log(num + '  ' + msg);
}


function evenorodd(num, callbackFunction) {
    if (num % 2 === 0) {
        callbackFunction(num, 'Even Number')
    } else {
        callbackFunction(num, 'Odd Number')
    }
}

evenorodd(10, fn);

