var ariths = {
    addition: (num1, num2) => {
        console.log('Sum is :' + num1 + num2)
    },
    multiplication: (num1, num2) => {
        console.log('product is :' + num1 * num2)
    },
    division: (num1, num2) => {
        console.log('Result is :' + num1 / num2)
    }
}



module.exports.myLibrary = ariths;