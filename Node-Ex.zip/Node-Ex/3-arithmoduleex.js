division = (num1, num2)=>{
    console.log('The result is : ' + (num1/num2))
}

module.export = division;