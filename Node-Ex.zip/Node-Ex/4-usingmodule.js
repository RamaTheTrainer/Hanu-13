var myFunction = require('./3-arithmoduleex.js');
myFunction(4,2);