var lib = require('./3-arithmoduleex.js');

lib.myLibrary.addition(50,0);
lib.myLibrary.multiplication(50,0);
lib.myLibrary.division(50,0);

