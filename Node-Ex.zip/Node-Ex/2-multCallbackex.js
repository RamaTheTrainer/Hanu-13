mydivision = (num1, num2, succCallback, errCallback) => {
    if (num2 === 0) {
        errCallback(num1, num2, 'Error bcz, Division not possible with 0..')
    } else {
        var result = num1 / num2;
        succCallback(result);
    }
}

sbf = (num) => {
    console.log('The result is : ' + num);
}
ebf = (n1, n2, errorMsg) => {
    console.log("Division of " + n1 + ' and ' + n2  + errorMsg);
}

mydivision(20, 5, sbf, ebf);
mydivision(20, 0, sbf, ebf);