var ev = require('events')
var evm = new ev.EventEmitter();

var fs = require('fs')
var path = require('path');
const { eventNames } = require('process');

var fileName = 'first.txt';

var rtf =  (fn)=> {
    rfilename = path.resolve(__dirname, fn);
    fs.readFile(rfilename, 'utf-8', (err, data) => {
        if (err) {
            console.log('Error ! ' + err);
        } else {
            console.log(data);
        }
    })
}

var wtf =  (fn, txt)=> {
    var sfilename = path.resolve(__dirname, fn)
    fs.writeFile(sfilename, txt, 'utf-8', (err) => {
        if (err) {
            console.log('Error Occured..! ' + err);
        } else {
            console.log("File saved successfully at : " + sfilename);
        }
    })
}

evm.on('readEvent', rtf);
evm.on('writeEvent', wtf);

// evm.emit('writeEvent','second.txt','Yes events concepts is a little intersting ...');
 evm.emit('readEvent','second.txt');

