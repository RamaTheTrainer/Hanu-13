
// importing events module 
var ev = require('events');

// creating event emitter object
var evm = new ev.EventEmitter();


// Attaching event handler to an event  
evm.on('reqReached',(nm)=>{
    console.log("Hey " + nm + " today is :" + new Date());
})

// firing event
evm.emit('reqReached','Rama');
evm.emit('reqReached','Hairsh');
evm.emit('reqReached','Siva krishna');
evm.emit('reqReached','Akash');
evm.emit('reqReached','Nikhil');





