console.log("Directory Name :  " + __dirname)
console.log("File Name  :  " +__filename)