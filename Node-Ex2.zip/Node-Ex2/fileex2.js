var fs = require('fs')
var path = require('path')

wfn = path.resolve(__dirname,'first.txt');

fs.stat(wfn,(err,stat)=>{
    if(err){
        console.log('Error occured!' + err);
    } else{
       console.log(stat.size);
    }
})



