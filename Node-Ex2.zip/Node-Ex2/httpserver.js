var http = require('http');

var requestHandler = (req, res) => {
    if (req.url === '/home') {
        res.write('<h1>Home Page</h1>')
        res.end();
    } else if (req.url === '/about') {
        res.write('<h1>About Us Page</h1>')
        res.end();
    }
    else {
        res.write('<h1>Welcome Page .... Learning Node JS</h1>')
        res.end()
    }
}

var server = http.createServer(requestHandler);

server.listen(9090, (err) => {
    if (err) {
        console.log('Error in creating web server ...')
    } else {
        console.log('Web server is running at  : 9090')
    }
})