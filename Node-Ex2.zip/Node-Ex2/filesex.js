//  ======================Writing from File =======================
// var fs = require('fs')
// var path = require('path')

// msg = 'We are working fine in Node js Enviroment ...';

// fileName = 'first.txt';
// var sfilename = path.resolve(__dirname, fileName)

// // console.log(sfilename);

// fs.writeFile(sfilename, msg, 'utf-8', (err) => {
//     if (err) {
//         console.log('Error Occured..! ' + err);
//     } else {
//         console.log("File saved successfully at : " + sfilename);
//     }
// })

//  ======================Reading from File =======================

var fs = require('fs');
var path = require('path');

fn = 'first.txt';

rfilename = path.resolve(__dirname, fn);

fs.readFile(rfilename, 'utf-8', (err, data) => {
    if (err) {
        console.log('Error ! ' + err);
    } else {
        console.log(data);
    }
})




