import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Movie } from '../models/movie';

@Injectable({
  providedIn: 'root'
})
export class MovieService {

  apiUrl = 'http://localhost:9090/api/';

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };


  constructor(private hc: HttpClient) { }

  getAllMovies(): Observable<any> {
    return this.hc.get(this.apiUrl + 'movies', { responseType: 'json' });
  }
  getMovieById(mid): Observable<any> {
    return this.hc.get(this.apiUrl + 'movies/' + mid, { responseType: 'json' })
  }
  addMovie(mobj: Movie): Observable<any> {
    return this.hc.post(this.apiUrl + 'movies', mobj, this.httpOptions);
  }
  deleteMovie(mid: string): Observable<any> {
    return this.hc.delete(this.apiUrl + 'movies/' + mid, { responseType: 'json' });
  }
  updateMovie(mobj: Movie) {
    return this.hc.put(this.apiUrl + 'movies', mobj, this.httpOptions);
  }

}
