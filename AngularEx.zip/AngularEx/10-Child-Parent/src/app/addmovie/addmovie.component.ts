import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { Movie } from '../models/movie';
import { MovieService } from '../services/movies.service';

@Component({
  selector: 'app-addmovie',
  templateUrl: './addmovie.component.html',
  styleUrls: ['./addmovie.component.css']
})
export class AddmovieComponent implements OnInit {

  movieForm: FormGroup;
  editMovieId: number;
  tempImgUrl: any;
  mObject: Movie = new Movie();
  constructor(
    private fb: FormBuilder,
    private movieService: MovieService,
    private acr: ActivatedRoute) { }

  ngOnInit() {
    this.createForm();
    this.editMovieId = this.acr.snapshot.params['id']
    if (this.editMovieId) {
      this.movieService.getMovieById(this.editMovieId).subscribe((resp) => {
        this.movieForm.controls['mid'].setValue(resp[0].mid);
        this.movieForm.controls['mname'].setValue(resp[0].mname);
        this.movieForm.controls['mposter'].setValue(resp[0].mposter);
        this.movieForm.controls['mdesc'].setValue(resp[0].mdesc);
        this.movieForm.controls['mhero'].setValue(resp[0].mhero);
        this.movieForm.controls['mdirector'].setValue(resp[0].mdirector);
        this.movieForm.controls['mawards'].setValue(resp[0].mawards);
      });
    }
  }

  createForm() {
    this.movieForm = this.fb.group({
      mid: [''],
      mname: [''],
      mposter: [],
      mdesc: [],
      mawards: [],
      mdirector: [],
      mhero: []
    })
  }
  saveMovie() {
    this.mObject.mid = this.movieForm.controls['mid'].value;
    this.mObject.mname = this.movieForm.controls['mname'].value;
    this.mObject.mdesc = this.movieForm.controls['mdesc'].value;
    this.mObject.mhero = this.movieForm.controls['mhero'].value;
    this.mObject.mawards = this.movieForm.controls['mawards'].value;
    this.mObject.mdirector = this.movieForm.controls['mdirector'].value;
    if (this.editMovieId) {
      this.movieService.updateMovie(this.mObject).subscribe((resp) => {
        if (resp) {
          alert('Updated Successfully');
        }
      })
    } else {
      this.movieService.addMovie(this.mObject).subscribe((resp) => {
        if (resp.message == 'Saved successfully') {
          alert('Movie saved successfully..')
          this.movieForm.reset();
          this.tempImgUrl= null;
        }
      })
    }
  }

  clearForm() {
    this.movieForm.reset();
  }

  fileUpload(event) {
    if (event.target.files[0]) {
      let fr = new FileReader();
      fr.readAsDataURL(event.target.files[0]);
      fr.onload = (ev: any) => {
        this.tempImgUrl = ev.target.result;
        this.mObject.mposter = fr.result.toString();
        this.mObject.mposter = this.mObject.mposter.replace('data:image/jpeg;base64,', '')
        this.mObject.mposter = this.mObject.mposter.replace('data:image/png;base64,', '')
        this.mObject.mposter = this.mObject.mposter.replace('data:image/gif;base64,', '')
      }
    }
  }
}
