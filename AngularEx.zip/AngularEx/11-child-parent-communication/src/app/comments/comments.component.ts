import { Component, Output, EventEmitter, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-comments',
  templateUrl: './comments.component.html',
  styleUrls: ['./comments.component.css']
})
export class CommentsComponent implements OnInit {

  @Output()
  countChangeEvent = new EventEmitter<number>();

  @Input()
  countValue;
  comments: string[] = [];
  constructor() { }

  ngOnInit() {
  }
  addComment(txtComment) {
    this.comments.push(txtComment);
    this.countChangeEvent.emit(this.comments.length);
  }
}
