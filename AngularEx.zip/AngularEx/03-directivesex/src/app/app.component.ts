import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'directivesex';
  course = 'react'

  cities = ['Delhi', 'Banglore', 'Mumbai', 'Hyderabad', 'Chennai']

  employees = [
    { eno: 1001, ename: 'Rita', city: 'Hyderabad' },
    { eno: 1002, ename: 'Gita', city: 'Banglore' },
    { eno: 1003, ename: 'Sita', city: 'Hyderabad' },
    { eno: 1004, ename: 'Nita', city: 'Hyderabad' },
    { eno: 1005, ename: 'Mita', city: 'Chennai' },
    { eno: 1006, ename: 'Bata', city: 'Hyderabad' },
    { eno: 1007, ename: 'Cata', city: 'Pune' },
  ]
  wvalue = 100 + 'px';

  rangeChange(r){
    this.wvalue = r*10 + 'px';
  }

}
