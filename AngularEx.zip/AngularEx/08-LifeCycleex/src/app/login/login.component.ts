import { AfterViewInit, Component, DoCheck, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit, DoCheck, OnChanges, AfterViewInit, OnDestroy {

  constructor() {
    alert('Constructor Executed')
  }

  ngOnInit() {
    alert('onInit Executed')
  }

  ngDoCheck() {
    alert('DoCheck Executed')
  }

  ngOnChanges(changes: SimpleChanges): void {
    alert('OnChanges Executed');
  }

  ngAfterViewInit() {
    alert('View Init Executed');
  }

  ngOnDestroy() {
    console.log('onDestroy Executed');
  }
}
