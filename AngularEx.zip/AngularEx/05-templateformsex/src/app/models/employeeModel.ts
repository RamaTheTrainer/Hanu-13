export class Employee{
    eid: number;
    ename : string;
    esalary: number;
    ecity : string;
    constructor(){
    }
}