import { Component } from '@angular/core';
import { Employee } from './models/employeeModel'
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'templateformsex';
  emp: Employee = new Employee();
  saveEmployee(){
    // send emp object to API URL 
  }
}
