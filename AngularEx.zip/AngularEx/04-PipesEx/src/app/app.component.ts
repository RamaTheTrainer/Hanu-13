import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
 

  employees = [
    { eno: 1001, ename: 'Rita', city: 'Hyderabad', salary : 3000, dob: new Date() },
    { eno: 1002, ename: 'Gita', city: 'Banglore', salary : 3500, dob: new Date() },
    { eno: 1003, ename: 'Sita', city: 'Hyderabad',  salary : 3800, dob: new Date() },
    { eno: 1004, ename: 'Nita', city: 'Delhi', salary : 3100, dob: new Date() },
    { eno: 1005, ename: 'Mita', city: 'Chennai' , salary : 3900, dob: new Date()},
    { eno: 1006, ename: 'Bata', city: 'Hyderabad' , salary : 4000, dob: new Date()},
    { eno: 1007, ename: 'Cata', city: 'Pune' , salary : 3500, dob: new Date()}
  ]

}
