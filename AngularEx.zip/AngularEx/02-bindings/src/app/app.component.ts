import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'bindings';

  studentName = "Pragnesh";
  course = 'MPC';
  fee = 3000;
  city = "Delhi";
  sliderValue = 90
  heroName = '';
  emp = { 'eno': 1003, 'ename': 'Rita', 'salary': 5000 };

  mybtnClick() {
    alert('This is event binding ...')
  }
  txtKeyUp(nm) {
    this.heroName = nm;
  }

  txtColorKeyUp(clr, hElement) {
    hElement.style.color = clr;
  }
}
