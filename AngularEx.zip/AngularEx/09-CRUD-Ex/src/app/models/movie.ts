export class Movie{
    mid:string;
    mname:string;
    mposter:string;
    mdesc:string;
    mawards:string;
    mdirector:string;
    mhero:string;
    constructor(){
    }
}