import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Movie } from '../models/movie';
import { MovieService } from '../services/movies.service';

@Component({
  selector: 'app-movies',
  templateUrl: './movies.component.html',
  styleUrls: ['./movies.component.css']
})
export class MoviesComponent implements OnInit {

  movies: Movie[] = [];
  totalClicks = 0;
  constructor(
    private movieService: MovieService,
    private router: Router) {
      
     }

  ngOnInit() {
    this.getMovies();
  }

  deleteMovie(mid) {
    this.movieService.deleteMovie(mid).subscribe((resp) => {
      if (resp.message == 'Deleted successfully') {
        alert('Deleted successfully');
        this.getMovies();
      }
    })
  }

  getMovies() {
    this.movieService.getAllMovies().subscribe((resp) => {
      this.movies = resp;
      console.log(this.movies)
    })
  }
  editMovie(mid: string) {
    this.router.navigate(['editmovie/' + mid])
  }
  incCountParent(event) {
    alert(event);
  }
}
