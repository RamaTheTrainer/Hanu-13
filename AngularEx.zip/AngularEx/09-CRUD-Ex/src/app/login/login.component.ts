import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { UserService } from '../services/user.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  constructor(
    private fb: FormBuilder,
    private userService: UserService,
    public router: Router) { }

  ngOnInit() {
    this.loginForm = this.fb.group({
      userid: [],
      password: []
    })
  }

  validateUser() {
    let userObj = { "userid": this.loginForm.controls['userid'].value, "password": this.loginForm.controls['password'].value }
    this.userService.validateUser(userObj).subscribe((resp) => {
      if (resp.length > 0) {
        alert('valid User')
        this.userService.isValidated = true;
        this.router.navigate(['/'])
      } else {
        alert('Invalid User details')
      }
    });
  }
}
