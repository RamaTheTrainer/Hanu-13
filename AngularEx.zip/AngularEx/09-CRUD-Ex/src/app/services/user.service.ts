import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class UserService {
  apiUrl = 'http://localhost:9090/api/';

  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  isValidated = false;
  constructor(private hc: HttpClient) { }

  validateUser(userObj): Observable<any> {
    return this.hc.post(this.apiUrl + 'user/authenticateUser', userObj, this.httpOptions);
  }
}
