import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientTestingModule} from '@angular/common/http/testing'
import { AddmovieComponent } from './addmovie.component';
import { MovieService } from '../services/movies.service';
import { ActivatedRoute } from '@angular/router';

describe('AddmovieComponent', () => {
  let component: AddmovieComponent;
  let fixture: ComponentFixture<AddmovieComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports:[ReactiveFormsModule, 
        HttpClientTestingModule],
      declarations: [ AddmovieComponent ],
      providers:[MovieService,
        {
          provide: ActivatedRoute, useValue: {
            snapshot: { params: { id: 123 } }
          }
        }
      ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AddmovieComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should check the movieForm validation',()=>{
    fixture = TestBed.createComponent(AddmovieComponent);
    component = fixture.componentInstance;
    component.createForm();
    component.movieForm.controls['mid'].setValue( 102);
    component.movieForm.controls['mname'].setValue('Thanaji');
    expect(component.movieForm.valid).toBeTruthy()
  })

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
