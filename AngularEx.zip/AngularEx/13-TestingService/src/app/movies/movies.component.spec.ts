import { HttpClientTestingModule } from '@angular/common/http/testing';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { Router } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { exec } from 'child_process';
import { of } from 'rxjs';
import { MovieComponent } from '../movie/movie.component';
import { MovieService } from '../services/movies.service';

import { MoviesComponent } from './movies.component';

describe('MoviesComponent', () => {
  let movieMockData = [
    { "mid": "1001", "mname": "Spiderman", "mposter": "http://localhost:9090/202228104029.png", "mdesc": "Scietfif thriller", "mawards": "filwfare", "mdirector": "Tom", "mhero": "Eddie" },
    { "mid": "1004", "mname": "Baji Rao ", "mposter": "http://localhost:9090/202228104927.png", "mdesc": "Romantic Romantic Epic ", "mawards": "filwfare", "mdirector": "Abbas", "mhero": "Ranveer" },
    { "mid": "1005", "mname": "Venom", "mposter": "http://localhost:9090/202228105018.png", "mdesc": "Scinvetfic", "mawards": "Oscar", "mdirector": "Jack Peters", "mhero": "Eddie" }
  ]

  let component: MoviesComponent;
  let fixture: ComponentFixture<MoviesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [MoviesComponent, MovieComponent],
      imports: [HttpClientTestingModule, RouterTestingModule],
      providers: [MovieService]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MoviesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    let mockService  = fixture.debugElement.injector.get(MovieService);
    spyOn(mockService,'getAllMovies').and.callFake(()=>{
      return of(movieMockData);
    })
    expect(component).toBeTruthy();
  });

  it('should call getMovies()',()=>{
    let mockService  = fixture.debugElement.injector.get(MovieService);
    spyOn(mockService,'getAllMovies').and.callFake(()=>{
      return of(movieMockData);
    })
    component.getMovies();
    expect(component.movies).toBe(movieMockData);
  })
});
