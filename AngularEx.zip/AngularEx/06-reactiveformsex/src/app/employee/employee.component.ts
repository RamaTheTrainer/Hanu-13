import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { Employee } from '../models/employeeModel';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  // FormBuilder is a service class . services must be injected into constructor 
  // constructor(private fb: FormBuild){ }
  empForm: FormGroup;
  constructor(private fb: FormBuilder) {

  }

  ngOnInit() {
    this.empForm = this.fb.group({
      eid: ['', Validators.required],
      ename: ['', Validators.required],
      esalary: [''],
      ecity: ['']
    })
  }

  saveEmployee() {
    if (this.empForm.valid) {
      let empObj = new Employee();
      empObj.eid = this.empForm.value.eid;
      empObj.ename = this.empForm.value.ename;
      empObj.esalary = this.empForm.value.esalary;
      empObj.ecity = this.empForm.value.ecity;
      // submit empObj to the api 
      alert(JSON.stringify(empObj));
    } else {
      alert('Validation erros please Check....')
    }
  }

  clearForm() {
    this.empForm.reset();
  }
}
