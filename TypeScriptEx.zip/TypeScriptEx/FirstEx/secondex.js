var Student = /** @class */ (function () {
    function Student() {
    }
    return Student;
}());
var studentList = [];
// an object or an array must be initialized before using it 
var stdObj;
// initialized the object will null values 
stdObj = new Student();
// Object assign the values 
stdObj.Sno = 1001;
stdObj.Sname = 'Rita';
stdObj.Fee = 3000;
studentList.push(stdObj);
var stdObj1 = new Student();
stdObj1.Sno = 1002;
stdObj1.Sname = 'Sita';
stdObj1.Fee = 3100;
studentList.push(stdObj1);
var stdObj2 = new Student();
stdObj2.Sno = 1003;
stdObj2.Sname = 'Gita';
stdObj2.Fee = 3500;
studentList.push(stdObj2);
console.log("Total students  : " + studentList.length);
/*
foreach  -  iterates through all the elements of the list
         - used a san output stmt
         - will works only on list
*/
// Display all the list 
studentList.forEach(function (elem) {
    console.log(elem.Sno, elem.Sname, elem.Fee);
});
// filtering in the list 
var filterList = studentList.filter(function (elem) { return elem.Sno === 1003; });
console.log('The filtered list length  : ' + filterList.length);
