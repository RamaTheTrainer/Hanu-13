var fn = 30;
var sn = 60;
var nm = 'rama';
function myfunction(x, y) {
    console.log('sum is' + (x + y));
}
myfunction(fn, sn);
