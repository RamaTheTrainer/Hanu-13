class Student {
    Sno: number;
    Sname: string;
    Fee: number;
    constructor() {

    }
}

let studentList: Student[] = []

// an object or an array must be initialized before using it 

let stdObj: Student;

// initialized the object will null values 
stdObj = new Student();

// Object assign the values 
stdObj.Sno = 1001;
stdObj.Sname = 'Rita';
stdObj.Fee = 3000;

studentList.push(stdObj);

let stdObj1 = new Student();
stdObj1.Sno = 1002;
stdObj1.Sname = 'Sita';
stdObj1.Fee = 3100;
studentList.push(stdObj1);


let stdObj2 = new Student();
stdObj2.Sno = 1003;
stdObj2.Sname = 'Gita';
stdObj2.Fee = 3500;
studentList.push(stdObj2);

console.log("Total students  : " +  studentList.length);


/*
foreach  -  iterates through all the elements of the list 
         - used a san output stmt 
         - will works only on list 
*/


// Display all the list 
studentList.forEach(elem=>{
    console.log(elem.Sno, elem.Sname, elem.Fee);
});


// filtering in the list 
let filterList = studentList.filter(elem=> elem.Sno === 1003);

console.log('The filtered list length  : ' + filterList.length);




