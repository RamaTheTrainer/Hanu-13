let fn: number = 30;
const sn : number = 60;
let nm : string ='rama';

function myfunction(x : number, y : number ): void {
    console.log('sum is' + (x+y))
}

myfunction(fn, sn);