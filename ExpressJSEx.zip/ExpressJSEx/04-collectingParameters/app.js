var express = require('express');

var app = express();


app.use(express.static(__dirname + '/assets'))

app.get('/products',(req,res)=>{
    res.send('Products page ')
})

app.get('/products/:pid',(req,res)=>{
    console.log(req.params.pid);
    res.send( 'product id : ' +req.params.pid +' Product details page ')
})

app.listen('9090', (err) => {
    if (err) {

    } else {
        console.log('Server is at : 9090')
    }
})