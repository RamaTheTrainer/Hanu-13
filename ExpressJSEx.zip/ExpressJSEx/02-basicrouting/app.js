// imporintg express
var express = require('express');

// instantiate express
var app = express();


// routes 
app.get('/', (req, res) => {
    res.send('<h2>Learning Express js ... Wleocme</h2>')
})
app.get('/about', (req, res) => {
    res.send('<h2>About Page</h2>')
})
app.get('/home', (req, res) => {
    '<h2>HOme Page </h2>'
})


// make the server avalaible at a port 
app.listen('9090', (err) => {
    if (err) {
        console.log('Error in starting express server..')
    } else {
        console.log('Server is running at : http://localhost:9090')
    }
})