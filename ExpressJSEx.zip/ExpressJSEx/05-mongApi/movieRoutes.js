var mongoClient = require('mongodb').MongoClient
var dbServerUrl = "mongodb://localhost:27017"
var express = require('express'); 
movieRouter = express.Router();

// retunrs all the movies list 
movieRouter.get('/movies', (req, res) => {
    mongoClient.connect(dbServerUrl, async (err, dbserver) => {
        if (err) {
            console.log('Error..! Unable to connect to mongoDB Server')
        } else {
            console.log("Connected succesfully to DB Server ..");
            dbo = dbserver.db("moviedb");
            data = await dbo.collection('movies').find().toArray()
            res.send(data);
        }
    })
})

// retunrs =movie details by movie id 
movieRouter.get('/movies/:id', (req, res) => {
    var movieId = req.params.id;
    var query = { "mid": movieId }
    mongoClient.connect(dbServerUrl, async (err, dbserver) => {
        if (err) {
            console.log('Error..! Unable to connect to mongoDB Server')
        } else {
            var dbo = dbserver.db('moviedb');
            var data = await dbo.collection('movies').find(query).toArray();
            res.send(data);
        }
    })
})

// Deletes a movie by movie Id
movieRouter.delete('/movies/:id', (req, res) => {
    var movieId = req.params.id;
    var query = { "mid": movieId };
    mongoClient.connect(dbServerUrl, async (err, dbserver) => {
        if (err) {
            console.log('Error..! Unable to connect to mongoDB Server')
        } else {
            var dbo = dbserver.db('moviedb');
            await dbo.collection('movies').deleteOne(query, (err) => {
                if (err) {
                    res.send({ "message": "Error in Deleting the record.." })
                } else {
                    res.send({ "message": "Deleted successfully" });
                }
            })
        }
    })
})


// Saves a new movie to DB
movieRouter.post('/movies', (req, res) => {
    var movieObject = {
        "mid": req.body.mid,
        "mname": req.body.mname,
        "mposter": req.body.mposter,
        "mdesc": req.body.mdesc,
        "mawards": req.body.mawards,
        "mdirector": req.body.mdirector,
        "mhero": req.body.mhero
    }
    mongoClient.connect(dbServerUrl, async (err, dbserver) => {
        if (err) {
            console.log('Error..! Unable to connect to mongoDB Server')
        } else {
            var dbo = dbserver.db('moviedb');
            await dbo.collection('movies').insertOne(movieObject, (err) => {
                if (err) {
                    res.send({ "message": "Error in Saving the record.." })
                } else {
                    res.send({ "message": "Saved successfully" });
                }
            })
        }
    })
})

// update a movie by movieId
movieRouter.put("/movies", (req, res) => {
    var movieUpObject = {
        "mid": req.body.mid,
        "mname": req.body.mname,
        "mposter": req.body.mposter,
        "mdesc": req.body.mdesc,
        "mawards": req.body.mawards,
        "mdirector": req.body.mdirector,
        "mhero": req.body.mhero
    }
    var query = {"mid": req.body.mid};
    var newObject = { $set: movieUpObject }
    mongoClient.connect(dbServerUrl, async (err, dbserver) => {
        if (err) {
            console.log('Error..! Unable to connect to mongoDB Server')
        } else {
            var dbo = dbserver.db('moviedb');
            await dbo.collection('movies').updateOne(query, newObject, (err) => {
                if (err) {
                    res.send({ "message": "Error in Updating .." })
                } else {
                    res.send({ "message": "Successfully updated.." })
                }
            })
        }
    })
})

module.exports = movieRouter