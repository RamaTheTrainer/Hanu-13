var mongoClient = require('mongodb').MongoClient
var dbServerUrl = "mongodb://localhost:27017"
var express = require('express');
userRouter = express.Router();

// retunrs =movie details by movie id 
userRouter.post('/authenticateUser', (req, res) => {
    var userObj =  {"userid": req.body.userid, "password": req.body.password}
    mongoClient.connect(dbServerUrl, async (err, dbserver) => {
        if (err) {
            console.log('Error..! Unable to connect to mongoDB Server')
        } else {
            var dbo = dbserver.db('moviedb');
            var data = await dbo.collection('users').find(userObj).toArray();
            console.log(data);
            res.send(data);
        }
    })
})

module.exports = userRouter