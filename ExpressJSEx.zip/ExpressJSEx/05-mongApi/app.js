var express = require('express');
var bodyParser = require('body-parser')
var movieRoutes  = require('./movieRoutes')
var app = express();

app.set('port', process.env.PORT || 9090);

app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
app.use('/api', movieRoutes);

app.get('/', (req, res) => {
    res.send('Welcome to node Mongo API ....')
})

app.listen(app.get('port'), (err) => {
    if (err) {
        console.log("Error in starting server ");
    } else {
        console.log("Server is running at  : " + app.get('port'));
    }
})
