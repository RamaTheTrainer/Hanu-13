var express = require('express');
var bodyParser = require('body-parser')
var path = require('path')
var cors = require('cors')
var movieRoutes = require('./movieRoutes')
var userRoutes = require('./userRoutes');
var app = express();

app.set('port', process.env.PORT || 9090);

app.use(bodyParser.urlencoded({ limit: "50mb", extended: false }))

app.use(bodyParser.json({limit: '50mb', type: 'application/json'}));
// app.use(bodyParser());
app.use(cors());
// app.use(express.json({limit: '100mb'}));
app.use(express.static(path.resolve(__dirname, 'images')))

app.use('/api', movieRoutes);
app.use('/api/user', userRoutes);
console.log(userRoutes)

app.get('/', (req, res) => {
    res.send('Welcome to node Mongo API ....')
})

app.listen(app.get('port'), (err) => {
    if (err) {
        console.log("Error in starting server ");
    } else {
        console.log("Server is running at  : " + app.get('port'));
    }
})
