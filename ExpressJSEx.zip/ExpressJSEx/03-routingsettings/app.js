var express = require('express')
var path = require('path')
var adminRoutes = require('./adminRoutes.js');
var userRoutes = require('./userRoutes');

var app = express();

app.set('port', process.env.PORT || 9095)

app.use('/user', userRoutes)
app.use('/admin', adminRoutes);

app.get('/', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'home.html'))
})

app.get('*', (req, res) => {
    res.sendFile(path.resolve(__dirname, 'error.html'))
})

app.listen(app.get('port'), (err) => {
    if (err)
        console.log('Erorr in starting the sever ')
    else {
        console.log('server started at  : http://localhost:' + app.get('port'))
    }
})