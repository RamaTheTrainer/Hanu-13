var express = require('express');
var adminRouter = express.Router();
adminRouter.get('/home', (req, res) => {
    res.send('<h1>Admin Home Page</h1>')
 })
adminRouter.get('/addproduct', (req, res) => {
    res.send('<h1>Admin Add Product Page</h1>')
 })
adminRouter.get('/userinfo', (req, res) => {
    res.send('<h1>Admin User Info Page</h1>')
 })
adminRouter.get('/displayproduct', (req, res) => {
    res.send('<h1>Admin Display Products  Page</h1>')
 })

module.exports = adminRouter;