var express = require('express');
var userRouter = express.Router();

userRouter.get('/home', (req, res) => {
    res.send('<h1>USer Hoome page </h1>')
})

userRouter.get('/about', (req, res) => {
    res.send('<h1>USer about page </h1>')
})

userRouter.get('/contact', (req, res) => {
    res.send('<h1>USer contact page </h1>')
})

userRouter.get('/displayproducts', (req, res) => {
    res.send('<h1>USer displayproducts page </h1>')
})

module.exports = userRouter