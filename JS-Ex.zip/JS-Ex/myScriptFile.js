sno = 1001;
sname = 'Eswar';
course = 'MPC';

var cities = ['Delhi', 'Mumbai', 'Kolkata', 'Hyderabad', 'Banglore', 'Chennai']

var students = [
    {Sno:1001, Sname:'Ramesh', Course:'MPC'},           
    {Sno:1002, Sname:'Rakesh', Course:'BPC'},           
    {Sno:1003, Sname:'Rajani', Course:'MPC'}            
];


function displayDate() {
    alert('Today is : ' + new Date());
}
function displayData() {
    document.getElementById('span_Sno').innerHTML = sno;
    document.getElementById('span_Sname').innerHTML = sname;
    document.getElementById('span_Course').innerHTML = course;
}

function displayCities() {
    //  document.getElementById('divCities').innerHTML = cities;
    var htmlString = '<ol>'
    for (i = 0; i < cities.length; i++) {
        htmlString += '<li>' + cities[i] + '</li>'
    }
    htmlString += '</ol>'
    document.getElementById('divCities').innerHTML = htmlString;
}

function displayStudents()
{
    var tblString='<table border="1px">'
    for(i = 0 ; i<students.length; i++){
       //  alert(JSON.stringify(students[i]))
       // JSON.parse()  - will converts the string to JSON OBJECT 
       // JSON.stringify() - Will converts JSON OBJECT into string 
       tblString+= '<tr>'
       tblString+= '<td>' + students[i].Sno +'</td>'
       tblString+= '<td>' + students[i].Sname +'</td>'
       tblString+= '<td>' + students[i].Course +'</td>'
       tblString+= '</tr>'
    }
    tblString+='</table>'
    document.getElementById('divStudents').innerHTML = tblString;
}





